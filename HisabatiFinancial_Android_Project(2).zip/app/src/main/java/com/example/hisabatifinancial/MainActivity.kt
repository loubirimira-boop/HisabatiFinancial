package com.example.hisabatifinancial

import android.app.Activity
import android.app.AlertDialog
import android.graphics.Color
import android.os.Bundle
import android.view.Gravity
import android.view.View
import android.widget.*
import org.json.JSONArray
import org.json.JSONObject
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

data class Entry(val id: Long, val type: String, val amount: Int, val time: Long)

class MainActivity : Activity() {
    private val prefs by lazy { getSharedPreferences("finance_data", MODE_PRIVATE) }
    private val entries = mutableListOf<Entry>()
    private lateinit var incomeTotal: TextView
    private lateinit var expenseTotal: TextView
    private lateinit var balanceTotal: TextView
    private lateinit var history: LinearLayout
    private lateinit var dailyTotal: TextView
    private lateinit var monthlyTotal: TextView

    private val green = Color.rgb(22, 128, 60)
    private val red = Color.rgb(185, 28, 28)
    private val paleGreen = Color.rgb(220, 252, 231)
    private val paleRed = Color.rgb(254, 226, 226)
    private val dark = Color.rgb(31, 41, 55)

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        loadEntries()
        buildScreen()
        refresh()
    }

    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()

    private fun buildScreen() {
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setBackgroundColor(Color.rgb(248, 250, 252))
            setPadding(dp(16), dp(14), dp(16), dp(12))
        }
        val scroll = ScrollView(this)
        val content = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        scroll.addView(content)

        content.addView(TextView(this).apply {
            text = "حساباتي المالية"
            textSize = 25f; setTextColor(dark); gravity = Gravity.CENTER
            typeface = android.graphics.Typeface.DEFAULT_BOLD
            setPadding(0, dp(6), 0, dp(18))
        })

        val totals = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        incomeTotal = totalCard("مجموع المداخيل", green, paleGreen)
        expenseTotal = totalCard("مجموع المصاريف", red, paleRed)
        totals.addView(incomeTotal, LinearLayout.LayoutParams(0, dp(105), 1f).apply { marginEnd = dp(6) })
        totals.addView(expenseTotal, LinearLayout.LayoutParams(0, dp(105), 1f).apply { marginStart = dp(6) })
        content.addView(totals)

        val balanceBox = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER
            setBackgroundColor(Color.WHITE)
            setPadding(dp(12), dp(12), dp(12), dp(12))
        }
        balanceBox.addView(TextView(this).apply {
            text = "الرصيد الصافي"; textSize = 16f; setTextColor(dark)
        })
        balanceTotal = TextView(this).apply {
            textSize = 27f; setTextColor(green)
            typeface = android.graphics.Typeface.DEFAULT_BOLD
        }
        balanceBox.addView(balanceTotal)
        val balanceParams = LinearLayout.LayoutParams(-1, dp(92))
        balanceParams.setMargins(0, dp(10), 0, dp(16))
        content.addView(balanceBox, balanceParams)

        content.addView(sectionTitle("إضافة مدخول"))
        content.addView(amountButtons("income", green, paleGreen))
        content.addView(sectionTitle("إضافة مصروف"))
        content.addView(amountButtons("expense", red, paleRed))

        content.addView(sectionTitle("ملخص الفترات"))
        dailyTotal = TextView(this).apply { textSize = 15f; setTextColor(dark); setPadding(dp(4), dp(5), dp(4), dp(5)) }
        monthlyTotal = TextView(this).apply { textSize = 15f; setTextColor(dark); setPadding(dp(4), dp(5), dp(4), dp(8)) }
        content.addView(dailyTotal)
        content.addView(monthlyTotal)

        val historyHeader = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
        }
        historyHeader.addView(sectionTitle("سجل العمليات"), LinearLayout.LayoutParams(0, -2, 1f))
        val clear = Button(this).apply {
            text = "مسح الكل"
            setOnClickListener {
                AlertDialog.Builder(this@MainActivity)
                    .setMessage("هل تريد حذف جميع العمليات؟")
                    .setNegativeButton("إلغاء", null)
                    .setPositiveButton("حذف") { _, _ ->
                        entries.clear(); saveEntries(); refresh()
                    }.show()
            }
        }
        historyHeader.addView(clear)
        content.addView(historyHeader)

        history = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        content.addView(history)

        root.addView(scroll, LinearLayout.LayoutParams(-1, 0, 1f))
        setContentView(root)
    }

    private fun totalCard(label: String, color: Int, bg: Int): TextView {
        return TextView(this).apply {
            text = "$label\n0 دج"; textSize = 17f; setTextColor(color)
            gravity = Gravity.CENTER; setBackgroundColor(bg)
            typeface = android.graphics.Typeface.DEFAULT_BOLD
        }
    }

    private fun sectionTitle(text: String) = TextView(this).apply {
        this.text = text; textSize = 18f; setTextColor(dark)
        typeface = android.graphics.Typeface.DEFAULT_BOLD
        setPadding(0, dp(9), 0, dp(8))
    }

    private fun amountButtons(type: String, color: Int, bg: Int): LinearLayout {
        val row = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        listOf(50, 100).forEach { amount ->
            val button = Button(this).apply {
                text = "$amount دج"
                textSize = 20f
                setTextColor(color)
                setBackgroundColor(bg)
                typeface = android.graphics.Typeface.DEFAULT_BOLD
                setOnClickListener {
                    entries.add(Entry(System.currentTimeMillis(), type, amount, System.currentTimeMillis()))
                    saveEntries()
                    refresh()
                }
            }
            row.addView(button, LinearLayout.LayoutParams(0, dp(58), 1f).apply {
                if (amount == 50) marginEnd = dp(6) else marginStart = dp(6)
            })
        }
        return row
    }

    private fun loadEntries() {
        try {
            val arr = JSONArray(prefs.getString("entries", "[]"))
            for (i in 0 until arr.length()) {
                val o = arr.getJSONObject(i)
                entries.add(Entry(o.getLong("id"), o.getString("type"), o.getInt("amount"), o.getLong("time")))
            }
        } catch (_: Exception) { entries.clear() }
    }

    private fun saveEntries() {
        val arr = JSONArray()
        entries.forEach {
            arr.put(JSONObject().put("id", it.id).put("type", it.type)
                .put("amount", it.amount).put("time", it.time))
        }
        prefs.edit().putString("entries", arr.toString()).apply()
    }

    private fun refresh() {
        val income = entries.filter { it.type == "income" }.sumOf { it.amount }
        val expense = entries.filter { it.type == "expense" }.sumOf { it.amount }
        incomeTotal.text = "مجموع المداخيل\n${fmt(income)} دج"
        expenseTotal.text = "مجموع المصاريف\n${fmt(expense)} دج"
        val balance = income - expense
        balanceTotal.text = "${fmt(balance)} دج"
        balanceTotal.setTextColor(if (balance >= 0) green else red)

        val now = System.currentTimeMillis()
        val dayFmt = SimpleDateFormat("yyyyMMdd", Locale.getDefault())
        val monthFmt = SimpleDateFormat("yyyyMM", Locale.getDefault())
        val today = dayFmt.format(Date(now))
        val month = monthFmt.format(Date(now))
        val dayIncome = entries.filter { it.type == "income" && dayFmt.format(Date(it.time)) == today }.sumOf { it.amount }
        val dayExpense = entries.filter { it.type == "expense" && dayFmt.format(Date(it.time)) == today }.sumOf { it.amount }
        val monthIncome = entries.filter { it.type == "income" && monthFmt.format(Date(it.time)) == month }.sumOf { it.amount }
        val monthExpense = entries.filter { it.type == "expense" && monthFmt.format(Date(it.time)) == month }.sumOf { it.amount }
        dailyTotal.text = "اليوم: المداخيل ${fmt(dayIncome)} دج | المصاريف ${fmt(dayExpense)} دج | الصافي ${fmt(dayIncome-dayExpense)} دج"
        monthlyTotal.text = "هذا الشهر: المداخيل ${fmt(monthIncome)} دج | المصاريف ${fmt(monthExpense)} دج | الصافي ${fmt(monthIncome-monthExpense)} دج"

        history.removeAllViews()
        if (entries.isEmpty()) {
            history.addView(TextView(this).apply {
                text = "لا توجد عمليات مسجلة بعد"; textSize = 14f; setTextColor(Color.GRAY)
                gravity = Gravity.CENTER; setPadding(0, dp(15), 0, dp(15))
            })
        } else {
            entries.sortedByDescending { it.time }.forEach { entry ->
                val row = LinearLayout(this).apply {
                    orientation = LinearLayout.HORIZONTAL
                    gravity = Gravity.CENTER_VERTICAL
                    setBackgroundColor(Color.WHITE)
                    setPadding(dp(10), dp(7), dp(5), dp(7))
                }
                val isIncome = entry.type == "income"
                val date = SimpleDateFormat("yyyy/MM/dd  HH:mm", Locale.getDefault()).format(Date(entry.time))
                val details = TextView(this).apply {
                    text = "${if (isIncome) "مدخول" else "مصروف"}: ${fmt(entry.amount)} دج\n$date"
                    textSize = 14f; setTextColor(if (isIncome) green else red)
                }
                row.addView(details, LinearLayout.LayoutParams(0, -2, 1f))
                val delete = Button(this).apply {
                    text = "حذف"
                    setOnClickListener {
                        AlertDialog.Builder(this@MainActivity)
                            .setMessage("حذف هذه العملية؟")
                            .setNegativeButton("إلغاء", null)
                            .setPositiveButton("حذف") { _, _ ->
                                entries.removeAll { it.id == entry.id }
                                saveEntries(); refresh()
                            }.show()
                    }
                }
                row.addView(delete)
                val params = LinearLayout.LayoutParams(-1, -2)
                params.setMargins(0, dp(3), 0, dp(3))
                history.addView(row, params)
            }
        }
    }

    private fun fmt(value: Int): String = String.format(Locale.US, "%,d", value)
}
